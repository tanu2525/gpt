// ZOHO.embeddedApp.on("PageLoad", function(data){

//     console.log("Widget Loaded");

//     console.log(data);

// });

// ZOHO.embeddedApp.init();

// document.getElementById("sendBtn").onclick=function(){

//     let phone=document.getElementById("phone").value;

//     let message=document.getElementById("message").value;

//     alert(
//         "Phone : "+phone+
//         "\n\nMessage : "+message
//     );

// };


document.getElementById("sendBtn").onclick = async function () {

    const phone = document.getElementById("phone").value;

    try {

        const response = await fetch("https://127.0.0.1:5000/send-whatsapp", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                mobile: phone
            })

        });

        const result = await response.json();

        console.log(result);

        alert("WhatsApp request sent successfully!");

    } catch (err) {

        console.error(err);

        alert("Failed to send WhatsApp.");

    }

};